<?php
declare(strict_types=1);

return [
    'HESTIA_BASE_URL'   => 'https://127.0.0.1:8083',
    'HESTIA_API_PATH'   => '/api/',
    'HESTIA_VERIFY_SSL' => false,

    'IMAPSYNC_BIN'      => '/usr/local/bin/imapsync',
    'JOBS_DIR'          => __DIR__ . '/../jobs',

    'ALLOW_ANY_HOST'    => true,
    'ALLOWED_HOSTS'     => [],

    'FORCE_SSL1'        => false,
    'FORCE_SSL2'        => false,

    'BRAND'             => 'BytesPulse Mailbox Migration',
    'SESSION_NAME'      => 'IMAPSYNC_UISESS',
];
