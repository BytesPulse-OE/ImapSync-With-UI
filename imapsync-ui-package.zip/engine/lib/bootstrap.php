<?php
declare(strict_types=1);

$config = require __DIR__ . '/../config/config.php';
date_default_timezone_set('Europe/Athens');

ini_set('session.use_strict_mode', '1');
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    ini_set('session.cookie_secure', '1');
}

session_name($config['SESSION_NAME'] ?? 'IMAPSYNC_UISESS');
session_start();

function cfg(string $key) { global $config; return $config[$key] ?? null; }

function json_response(array $payload, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function require_auth(): void {
    if (empty($_SESSION['auth']) || empty($_SESSION['auth']['user'])) {
        json_response(['ok' => false, 'error' => 'Unauthorized'], 401);
    }
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function check_csrf(?string $token): void {
    $expected = $_SESSION['csrf'] ?? '';
    if (!$token || !$expected || !hash_equals($expected, $token)) {
        json_response(['ok' => false, 'error' => 'Bad CSRF token'], 400);
    }
}

function is_valid_host(string $h): bool {
    if ($h === '' || strlen($h) > 253) return false;
    if (preg_match('/^\[[0-9a-fA-F:]+\]$/', $h)) return true;
    if (preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $h)) return true;
    return (bool)preg_match('/^(?=.{1,253}$)([a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,63}$/', $h);
}

function host_allowed(string $host): bool {
    if (cfg('ALLOW_ANY_HOST')) return true;
    $allowed = cfg('ALLOWED_HOSTS') ?: [];
    return in_array($host, $allowed, true);
}

function ensure_jobs_dir(string $user): string {
    $base = cfg('JOBS_DIR');
    if (!$base) throw new RuntimeException('JOBS_DIR missing');
    if (!is_dir($base)) @mkdir($base, 0750, true);

    $safe = preg_replace('/[^a-zA-Z0-9_.-]/', '_', $user);
    $dir = rtrim($base, '/') . '/' . $safe;

    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    if (!is_writable($dir)) throw new RuntimeException('Jobs dir not writable: ' . $dir);
    return $dir;
}
