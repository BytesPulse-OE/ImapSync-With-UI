<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function hestia_api_call(array $auth, string $cmd, array $args = [], bool $returncode = true): array {
    $base = rtrim((string)cfg('HESTIA_BASE_URL'), '/');
    $url = $base . (string)cfg('HESTIA_API_PATH');

    $post = ['returncode' => $returncode ? 'yes' : 'no', 'cmd' => $cmd];

    if (($auth['mode'] ?? '') === 'hash') {
        $post['hash'] = (string)($auth['hash'] ?? '');
        if ($post['hash'] === '') return ['ok' => false, 'error' => 'Missing Hestia hash'];
    } elseif (($auth['mode'] ?? '') === 'password') {
        $post['user'] = (string)($auth['user'] ?? '');
        $post['password'] = (string)($auth['password'] ?? '');
        if ($post['user'] === '' || $post['password'] === '') return ['ok' => false, 'error' => 'Missing user/password'];
    } else {
        return ['ok' => false, 'error' => 'Unknown auth mode'];
    }

    $i = 1;
    foreach ($args as $a) { $post['arg'.$i] = $a; $i++; }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query($post),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_CONNECTTIMEOUT => 10,
    ]);

    $verify = (bool)cfg('HESTIA_VERIFY_SSL');
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $verify);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $verify ? 2 : 0);

    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($resp === false) return ['ok' => false, 'error' => 'cURL error: '.$err];
    if ($code !== 200) return ['ok' => false, 'error' => 'Hestia HTTP '.$code, 'raw' => $resp];

    if ($returncode) {
        $trim = trim($resp);
        if ($trim !== '0') return ['ok' => false, 'error' => 'Hestia returncode: '.$trim];
    }

    return ['ok' => true];
}

function hestia_validate_user_dual(string $username, string $credential, ?string $secret): array {
    $username = trim($username);
    $credential = (string)$credential;
    $secret = $secret !== null ? trim((string)$secret) : '';

    if ($username === '' || $credential === '') return ['ok' => false, 'error' => 'Missing credentials'];

    if ($secret !== '') {
        $auth = ['mode' => 'hash', 'hash' => $credential . ':' . $secret];
        $r = hestia_api_call($auth, 'v-list-user', [$username], true);
        if (!$r['ok']) return $r;
        return ['ok' => true, 'user' => $username, 'login_mode' => 'access_key'];
    }

    $auth = ['mode' => 'password', 'user' => $username, 'password' => $credential];
    $r = hestia_api_call($auth, 'v-list-user', [$username], true);
    if (!$r['ok']) return ['ok' => false, 'error' => 'Password login failed (API may not allow password auth). Use Access/Secret Key instead.'];
    return ['ok' => true, 'user' => $username, 'login_mode' => 'password'];
}
