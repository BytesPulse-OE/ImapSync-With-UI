<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function i18n_lang(): string {
    $q = $_GET['lang'] ?? '';
    if ($q === 'en' || $q === 'el') { $_SESSION['lang'] = $q; return $q; }
    $s = $_SESSION['lang'] ?? '';
    if ($s === 'en' || $s === 'el') return $s;

    $al = $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '';
    $_SESSION['lang'] = (stripos($al, 'el') !== false) ? 'el' : 'en';
    return $_SESSION['lang'];
}
function other_lang(): string { return i18n_lang() === 'el' ? 'en' : 'el'; }

function t(string $k): string {
    static $d = null;
    if ($d === null) {
        $d = [
            'en' => [
                'header_sub' => 'BytesPulse UI • Server-side imapsync • Script by Lamiral',
                'login_title' => 'Login',
                'login_desc' => 'Enter username and either Password or Access Key. If Secret Key is set, 2nd field is treated as Access Key.',
                'username' => 'Username',
                'password_or_access' => 'Password / Access Key',
                'secret_optional' => 'Secret Key (optional)',
                'login_btn' => 'Login',
                'logout' => 'Logout',
                'logged_in_as' => 'Logged in as',
                'hestia_login' => 'HestiaCP login',
                'note_api_password' => 'Note: Some Hestia installs disable API password auth. In that case use Access/Secret Key.',
                'need_access_key' => 'Need an Access Key?',
                'steps_title' => 'How to create an Access/Secret Key in Hestia',
                'steps_1' => 'Log in to HestiaCP',
                'steps_2' => 'Open User Profile → Access Keys',
                'steps_3' => 'Click “Add Access Key”',
                'steps_4' => 'Allow API command: v-list-user',
                'steps_5' => 'Copy Access/Secret keys and use them here',
                'migration_title' => 'Migration details',
                'migration_desc' => 'IMAP passwords are not stored. Logs are stored per user.',
                'sender' => 'Sender (Source IMAP)',
                'receiver' => 'Receiver (Target IMAP)',
                'host_or_ip' => 'Host or IP (e.g. mail.example.com)',
                'port' => 'Port',
                'ssl' => 'SSL/TLS',
                'user_email' => 'User / Email',
                'password' => 'Password',
                'options' => 'Options',
                'test_only' => 'Test only (credentials / no copy)',
                'foldersizes' => 'Show folder sizes',
                'stability' => 'Stability flags (retries/timeouts/cache)',
                'start' => 'Start migration',
                'stop' => 'Stop',
                'logs' => 'Live logs',
                'job' => 'Job',
                'idle' => 'Idle',
                'download_log' => 'Download log',
                'tip' => 'Tip: For Microsoft 365 / Gmail you may need an app password or OAuth2. This UI supports OAuth2 via an access token.',
                'missing_field' => 'Missing field',
                'port_numeric' => 'Port must be numeric',
                'running' => 'Running',
                'start_failed' => 'Start failed',
                'provider' => 'Provider',
                'custom' => 'Custom',
                'gmail' => 'Gmail',
                'office365' => 'Microsoft 365',
                'auth_method' => 'Auth method',
                'auth_password' => 'Password',
                'auth_oauth2' => 'OAuth2 access token',
                'access_token' => 'Access token',
                'progress' => 'Progress',
            ],
            'el' => [
                'header_sub' => 'BytesPulse UI • Server-side imapsync • Script by Lamiral',
                'login_title' => 'Σύνδεση',
                'login_desc' => 'Βάλε username και είτε Password είτε Access Key. Αν συμπληρώσεις Secret Key, το 2ο πεδίο θεωρείται Access Key.',
                'username' => 'Username',
                'password_or_access' => 'Password / Access Key',
                'secret_optional' => 'Secret Key (προαιρετικό)',
                'login_btn' => 'Σύνδεση',
                'logout' => 'Αποσύνδεση',
                'logged_in_as' => 'Συνδεδεμένος ως',
                'hestia_login' => 'Σύνδεση HestiaCP',
                'note_api_password' => 'Σημείωση: Σε κάποιες εγκαταστάσεις Hestia, το API δεν επιτρέπει password auth. Χρησιμοποίησε Access/Secret Key.',
                'need_access_key' => 'Χρειάζεσαι Access Key;',
                'steps_title' => 'Πώς φτιάχνεις Access/Secret Key στο Hestia',
                'steps_1' => 'Κάνε login στο HestiaCP',
                'steps_2' => 'User Profile → Access Keys',
                'steps_3' => 'Πάτα “Add Access Key”',
                'steps_4' => 'Δώσε API permission: v-list-user',
                'steps_5' => 'Αντέγραψε Access/Secret keys και βάλε τα εδώ',
                'migration_title' => 'Στοιχεία μεταφοράς',
                'migration_desc' => 'Δεν αποθηκεύονται IMAP κωδικοί. Τα logs αποθηκεύονται ανά χρήστη.',
                'sender' => 'Αποστολέας (Source IMAP)',
                'receiver' => 'Παραλήπτης (Target IMAP)',
                'host_or_ip' => 'Host ή IP (π.χ. mail.example.com)',
                'port' => 'Port',
                'ssl' => 'SSL/TLS',
                'user_email' => 'User / Email',
                'password' => 'Password',
                'options' => 'Επιλογές',
                'test_only' => 'Μόνο έλεγχος (credentials / no copy)',
                'foldersizes' => 'Εμφάνιση folder sizes',
                'stability' => 'Stability flags (retries/timeouts/cache)',
                'start' => 'Έναρξη',
                'stop' => 'Stop',
                'logs' => 'Live logs',
                'job' => 'Job',
                'idle' => 'Idle',
                'download_log' => 'Download log',
                'tip' => 'Tip: Για Microsoft 365 / Gmail ίσως χρειάζεται app password ή OAuth2. Το UI υποστηρίζει OAuth2 μέσω access token.',
                'missing_field' => 'Λείπει πεδίο',
                'port_numeric' => 'Το port πρέπει να είναι αριθμός',
                'running' => 'Running',
                'start_failed' => 'Αποτυχία εκκίνησης',
                'provider' => 'Πάροχος',
                'custom' => 'Custom',
                'gmail' => 'Gmail',
                'office365' => 'Microsoft 365',
                'auth_method' => 'Τύπος σύνδεσης',
                'auth_password' => 'Password',
                'auth_oauth2' => 'OAuth2 access token',
                'access_token' => 'Access token',
                'progress' => 'Πρόοδος',
            ],
        ];
    }
    $lang = i18n_lang();
    return $d[$lang][$k] ?? $k;
}
