<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

function build_imapsync_command(array $in): array
{
    $provider1 = (string)($in['provider1'] ?? 'custom'); // custom|gmail|office365
    $provider2 = (string)($in['provider2'] ?? 'custom');
    $auth1     = (string)($in['auth1'] ?? 'password');  // password|oauth2
    $auth2     = (string)($in['auth2'] ?? 'password');

    $needHost1 = ($provider1 === 'custom');
    $needHost2 = ($provider2 === 'custom');

    $required = ['user1','user2'];
    if ($needHost1) array_push($required, 'host1','port1','ssl1');
    if ($needHost2) array_push($required, 'host2','port2','ssl2');

    if ($auth1 === 'password') $required[] = 'pass1';
    if ($auth2 === 'password') $required[] = 'pass2';
    if ($auth1 === 'oauth2')   $required[] = 'token1';
    if ($auth2 === 'oauth2')   $required[] = 'token2';

    foreach ($required as $k) {
        if (!isset($in[$k]) || $in[$k] === '') {
            throw new InvalidArgumentException("Missing: $k");
        }
    }

    if ($needHost1) {
        $host1 = (string)$in['host1'];
        if (!is_valid_host($host1)) throw new InvalidArgumentException('Invalid host1');
        if (!host_allowed($host1)) throw new InvalidArgumentException('Host1 not allowed');
        if (!ctype_digit((string)$in['port1'])) throw new InvalidArgumentException('Invalid port1');
    }
    if ($needHost2) {
        $host2 = (string)$in['host2'];
        if (!is_valid_host($host2)) throw new InvalidArgumentException('Invalid host2');
        if (!host_allowed($host2)) throw new InvalidArgumentException('Host2 not allowed');
        if (!ctype_digit((string)$in['port2'])) throw new InvalidArgumentException('Invalid port2');
    }

    $cmd = [];
    $cmd[] = (string)cfg('IMAPSYNC_BIN');

    // imapsync provider shortcuts
    if ($provider1 === 'gmail')     $cmd[] = '--gmail1';
    if ($provider2 === 'gmail')     $cmd[] = '--gmail2';
    if ($provider1 === 'office365') $cmd[] = '--office1';
    if ($provider2 === 'office365') $cmd[] = '--office2';

    // custom host
    if ($needHost1) {
        $cmd[] = '--host1'; $cmd[] = (string)$in['host1'];
        $cmd[] = '--port1'; $cmd[] = (string)$in['port1'];
        if (((int)$in['ssl1'] === 1) || (bool)cfg('FORCE_SSL1')) $cmd[] = '--ssl1';
    } else {
        if ((bool)cfg('FORCE_SSL1')) $cmd[] = '--ssl1';
    }

    if ($needHost2) {
        $cmd[] = '--host2'; $cmd[] = (string)$in['host2'];
        $cmd[] = '--port2'; $cmd[] = (string)$in['port2'];
        if (((int)$in['ssl2'] === 1) || (bool)cfg('FORCE_SSL2')) $cmd[] = '--ssl2';
    } else {
        if ((bool)cfg('FORCE_SSL2')) $cmd[] = '--ssl2';
    }

    // users
    $cmd[] = '--user1'; $cmd[] = (string)$in['user1'];
    $cmd[] = '--user2'; $cmd[] = (string)$in['user2'];

    // auth
    if ($auth1 === 'oauth2') {
        $cmd[] = '--authmech1'; $cmd[] = 'XOAUTH2';
        $cmd[] = '--oauthaccesstoken1'; $cmd[] = (string)$in['token1'];
    } else {
        $cmd[] = '--password1'; $cmd[] = (string)$in['pass1'];
    }

    if ($auth2 === 'oauth2') {
        $cmd[] = '--authmech2'; $cmd[] = 'XOAUTH2';
        $cmd[] = '--oauthaccesstoken2'; $cmd[] = (string)$in['token2'];
    } else {
        $cmd[] = '--password2'; $cmd[] = (string)$in['pass2'];
    }

    // options
    if (!empty($in['dryrun'])) $cmd[] = '--justlogin';
    if (!empty($in['justfoldersizes'])) $cmd[] = '--foldersizes';
    if (!empty($in['automap'])) {
        $cmd[] = '--usecache';
        $cmd[] = '--reconnectretry1'; $cmd[] = '3';
        $cmd[] = '--reconnectretry2'; $cmd[] = '3';
        $cmd[] = '--timeout1'; $cmd[] = '120';
        $cmd[] = '--timeout2'; $cmd[] = '120';
    }

    return $cmd;
}

function launch_job(string $user, array $input): array
{
    $dir = ensure_jobs_dir($user);
    $job = bin2hex(random_bytes(16));
    $logFile = $dir . "/$job.log";
    $pidFile = $dir . "/$job.pid";
    $stateFile = $dir . "/$job.state";

    file_put_contents($stateFile, "Running");

    $cmd = build_imapsync_command($input);
    $escaped = array_map('escapeshellarg', $cmd);

    $full = implode(' ', $escaped) . " >> " . escapeshellarg($logFile) . " 2>&1 & echo $!";
    $pid = trim((string)shell_exec($full));

    if (!$pid || !ctype_digit($pid)) {
        file_put_contents($stateFile, "Failed");
        return ['ok' => false, 'error' => 'Failed to start (shell_exec disabled or process failed)'];
    }

    file_put_contents($pidFile, $pid);
    return ['ok' => true, 'job' => $job];
}

function job_status(string $user, string $job): array
{
    $dir = ensure_jobs_dir($user);
    if (!preg_match('/^[a-f0-9]{32}$/', $job)) throw new InvalidArgumentException('Invalid job');

    $logf = "$dir/$job.log";
    $pidf = "$dir/$job.pid";
    $statef = "$dir/$job.state";

    $state = is_file($statef) ? trim((string)file_get_contents($statef)) : 'Unknown';
    $pid = is_file($pidf) ? trim((string)file_get_contents($pidf)) : '';
    $running = false;
    if ($pid && ctype_digit($pid) && function_exists('posix_kill')) $running = @posix_kill((int)$pid, 0);

    $log = is_file($logf) ? (string)file_get_contents($logf) : '';

    if ($state === 'Running' && !$running) {
        $state = (stripos($log, 'Exiting with return value 0') !== false) ? 'Finished' : 'Failed';
        @file_put_contents($statef, $state);
    }

    return ['state' => $state, 'log' => $log];
}

function job_stop(string $user, string $job): array
{
    $dir = ensure_jobs_dir($user);
    if (!preg_match('/^[a-f0-9]{32}$/', $job)) throw new InvalidArgumentException('Invalid job');

    $pidf = "$dir/$job.pid";
    $statef = "$dir/$job.state";

    $pid = is_file($pidf) ? trim((string)file_get_contents($pidf)) : '';
    if ($pid && ctype_digit($pid) && function_exists('posix_kill')) {
        @posix_kill((int)$pid, SIGTERM);
        @file_put_contents($statef, 'Stopped');
        return ['ok' => true];
    }
    return ['ok' => false, 'error' => 'Cannot stop'];
}
