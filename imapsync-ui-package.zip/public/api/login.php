<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/hestia.php';

$in = json_decode(file_get_contents('php://input'), true) ?: [];
check_csrf($in['csrf'] ?? null);

$r = hestia_validate_user_dual((string)($in['username'] ?? ''), (string)($in['credential'] ?? ''), isset($in['secret']) ? (string)$in['secret'] : '');
if (!$r['ok']) json_response(['ok'=>false,'error'=>$r['error'] ?? 'Login failed'], 401);

$_SESSION['auth'] = ['user'=>$r['user'], 'login_mode'=>$r['login_mode'] ?? 'unknown', 'at'=>time()];
json_response(['ok'=>true, 'mode'=>$_SESSION['auth']['login_mode']]);
