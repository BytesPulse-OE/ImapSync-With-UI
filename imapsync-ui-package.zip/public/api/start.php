<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/imapsync.php';

require_auth();
$in = json_decode(file_get_contents('php://input'), true) ?: [];
check_csrf($in['csrf'] ?? null);

try {
  $r = launch_job((string)$_SESSION['auth']['user'], $in);
  if (!$r['ok']) json_response($r, 500);
  json_response(['ok'=>true,'job'=>$r['job']]);
} catch (Throwable $e) {
  json_response(['ok'=>false,'error'=>$e->getMessage()], 400);
}
