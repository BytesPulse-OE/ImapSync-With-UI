<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/imapsync.php';

require_auth();
$job = (string)($_GET['job'] ?? '');

try {
  $s = job_status((string)$_SESSION['auth']['user'], $job);
} catch (Throwable $e) {
  json_response(['ok'=>false,'error'=>$e->getMessage()], 400);
}

if (isset($_GET['download']) && $_GET['download'] == '1') {
  header('Content-Type: text/plain; charset=utf-8');
  header('Content-Disposition: attachment; filename="imapsync-'.$job.'.log"');
  echo $s['log'] ?? '';
  exit;
}

json_response(['ok'=>true,'state'=>$s['state'] ?? 'Unknown','log'=>$s['log'] ?? '']);
