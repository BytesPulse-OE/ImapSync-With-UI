<?php
declare(strict_types=1);

require_once __DIR__ . '/../lib/bootstrap.php';
require_once __DIR__ . '/../lib/imapsync.php';

require_auth();
$in = json_decode(file_get_contents('php://input'), true) ?: [];
check_csrf($in['csrf'] ?? null);

$r = job_stop((string)$_SESSION['auth']['user'], (string)($in['job'] ?? ''));
if (!$r['ok']) json_response($r, 400);
json_response(['ok'=>true]);
