(function(){
  const root = document.documentElement;
  const cfg = window.__APP_CONFIG || {};
  const sel = (id) => document.getElementById(id);

  function applyTheme(mode){
    if(mode === 'dark'){
      root.classList.add('dark');
      const b = sel('themeBtn'); if(b) b.textContent = '☀️';
    } else {
      root.classList.remove('dark');
      const b = sel('themeBtn'); if(b) b.textContent = '🌙';
    }
    try { localStorage.setItem('bp_theme', mode); } catch(e) {}
  }

  function initTheme(){
    const btn = sel('themeBtn');
    if(!btn) return;
    let saved = null;
    try { saved = localStorage.getItem('bp_theme'); } catch(e) {}
    if(saved === 'dark' || saved === 'light'){
      applyTheme(saved);
    } else {
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      applyTheme(prefersDark ? 'dark' : 'light');
    }
    btn.addEventListener('click', () => {
      applyTheme(root.classList.contains('dark') ? 'light' : 'dark');
    });
  }

  function show(el, text){
    if(!el) return;
    el.textContent = text || '';
    el.classList.remove('hidden');
  }
  function hide(el){
    if(!el) return;
    el.classList.add('hidden');
  }

  async function jsonPost(url, payload){
    const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const data = await res.json().catch(()=> ({}));
    return { res, data };
  }

  function initLogin(){
    const form = sel('loginForm');
    if(!form) return;
    const msg = sel('loginMsg');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      hide(msg);
      const payload = Object.fromEntries(new FormData(form).entries());
      const { data } = await jsonPost('/api/login.php', payload);
      if(!data.ok) return show(msg, data.error || 'Login failed');
      window.location = '/';
    });
  }

  function initPasswordToggles(){
    const btns = document.querySelectorAll('[data-toggle]');
    btns.forEach((btn) => {
      btn.addEventListener('click', () => {
        const idOrName = btn.getAttribute('data-toggle');
        if(!idOrName) return;
        let input = document.getElementById(idOrName);
        if(!input){
          input = document.querySelector('input[name="'+CSS.escape(idOrName)+'"]');
        }
        if(!input) return;
        const isPw = input.getAttribute('type') === 'password';
        input.setAttribute('type', isPw ? 'text' : 'password');
        btn.textContent = isPw ? '🙈' : '👁';
      });
    });
  }

  const presets = {
    gmail: { host: 'imap.gmail.com', port: '993', ssl: true },
    office365: { host: 'outlook.office365.com', port: '993', ssl: true },
    custom: null,
  };

  function applyProvider(side){
    const provSel = sel('provider'+side);
    if(!provSel) return;
    const prov = provSel.value;
    const host = sel('host'+side);
    const port = sel('port'+side);
    const ssl  = sel('ssl'+side);
    if(!host || !port || !ssl) return;

    if(prov === 'custom'){
      host.disabled = false; port.disabled = false; ssl.disabled = false;
    } else {
      const p = presets[prov];
      host.value = p.host; port.value = p.port; ssl.checked = p.ssl;
      host.disabled = true; port.disabled = true; ssl.disabled = true;
    }
  }

  function applyAuth(side){
    const aSel = sel('auth'+side);
    if(!aSel) return;
    const a = aSel.value;
    const passBlock = sel((side==1?'sender':'receiver')+'PassBlock');
    const tokenBlock = sel((side==1?'sender':'receiver')+'TokenBlock');
    if(a === 'oauth2'){
      if(passBlock) passBlock.classList.add('hidden');
      if(tokenBlock) tokenBlock.classList.remove('hidden');
    } else {
      if(tokenBlock) tokenBlock.classList.add('hidden');
      if(passBlock) passBlock.classList.remove('hidden');
    }
  }

  function inferProgress(log){
    const re = /(\b\d{1,3})\s*%/g;
    let m, best = -1;
    while((m = re.exec(log)) !== null){
      const v = parseInt(m[1], 10);
      if(!isNaN(v) && v >= 0 && v <= 100) best = Math.max(best, v);
    }
    return best >= 0 ? best : null;
  }

  function initMigration(){
    const startBtn = sel('startBtn');
    if(!startBtn) return;

    const msg = sel('msg');
    const stopBtn = sel('stopBtn');
    const downloadBtn = sel('downloadBtn');
    const jobEl = sel('jobId');
    const stateEl = sel('state');
    const logEl = sel('log');

    const progressFill = sel('progressFill');
    const progressPulse = sel('progressPulse');
    const progressPct = sel('progressPct');

    let currentJob = null;
    let pollTimer = null;

    function setProgress(pct){
      if(!progressFill || !progressPulse || !progressPct) return;
      if(pct === null){
        progressFill.style.width = '0%';
        progressPulse.classList.remove('hidden');
        progressPct.textContent = '—';
        return;
      }
      progressPulse.classList.add('hidden');
      const clamped = Math.max(0, Math.min(100, pct));
      progressFill.style.width = clamped + '%';
      progressPct.textContent = clamped.toFixed(0) + '%';
    }

    function getPayload(){
      return {
        csrf: sel('csrf').value,

        provider1: sel('provider1').value,
        auth1: sel('auth1').value,
        host1: sel('host1').value.trim(),
        port1: sel('port1').value.trim(),
        ssl1: sel('ssl1').checked ? 1 : 0,
        user1: sel('user1').value.trim(),
        pass1: sel('pass1') ? sel('pass1').value : '',
        token1: sel('token1') ? sel('token1').value.trim() : '',

        provider2: sel('provider2').value,
        auth2: sel('auth2').value,
        host2: sel('host2').value.trim(),
        port2: sel('port2').value.trim(),
        ssl2: sel('ssl2').checked ? 1 : 0,
        user2: sel('user2').value.trim(),
        pass2: sel('pass2') ? sel('pass2').value : '',
        token2: sel('token2') ? sel('token2').value.trim() : '',

        dryrun: sel('dryrun').checked ? 1 : 0,
        justfoldersizes: sel('justfoldersizes').checked ? 1 : 0,
        automap: sel('automap').checked ? 1 : 0,
      };
    }

    function validate(p){
      const required = ['user1','user2'];
      if(p.provider1 === 'custom') required.push('host1','port1');
      if(p.provider2 === 'custom') required.push('host2','port2');
      if(p.auth1 === 'password') required.push('pass1'); else required.push('token1');
      if(p.auth2 === 'password') required.push('pass2'); else required.push('token2');

      for(const k of required){
        if(!p[k]) return (cfg.missingField || 'Missing field') + ': ' + k;
      }
      if(!/^\d+$/.test(p.port1) || !/^\d+$/.test(p.port2)){
        return cfg.portNumeric || 'Port must be numeric';
      }
      return null;
    }

    async function poll(){
      if(!currentJob) return;
      const res = await fetch('/api/status.php?job=' + encodeURIComponent(currentJob) + '&t=' + Date.now());
      const data = await res.json().catch(()=> ({}));
      if(!data.ok) return;
      const log = data.log || '';
      if(logEl) logEl.textContent = log;
      if(stateEl) stateEl.textContent = data.state || '';
      const pct = inferProgress(log);
      setProgress(pct);

      if(['Finished','Failed','Stopped'].includes(data.state)){
        clearInterval(pollTimer); pollTimer = null;
        if(stopBtn) stopBtn.disabled = true;
        if(startBtn) startBtn.disabled = false;
        if(downloadBtn) downloadBtn.disabled = false;
        // Progress heuristic can be misleading on small jobs; force final state.
        if(data.state === 'Finished'){
          setProgress(100);
        } else if(pct === null) {
          setProgress(0);
        }
      }
    }

    async function start(){
      hide(msg);
      const payload = getPayload();
      const err = validate(payload);
      if(err) return show(msg, err);

      startBtn.disabled = true;
      setProgress(null);

      const { data } = await jsonPost('/api/start.php', payload);
      if(!data.ok){
        startBtn.disabled = false;
        setProgress(0);
        return show(msg, data.error || cfg.startFailed || 'Start failed');
      }
      currentJob = data.job;
      if(jobEl) jobEl.textContent = currentJob;
      if(stateEl) stateEl.textContent = cfg.running || 'Running';
      if(stopBtn) stopBtn.disabled = false;
      if(downloadBtn) downloadBtn.disabled = true;
      if(logEl) logEl.textContent = '';

      pollTimer = setInterval(poll, 1200);
      poll();
    }

    async function stop(){
      if(!currentJob) return;
      await jsonPost('/api/stop.php', { job: currentJob, csrf: sel('csrf').value });
    }

    startBtn.addEventListener('click', (e)=>{ e.preventDefault(); start(); });
    if(stopBtn) stopBtn.addEventListener('click', (e)=>{ e.preventDefault(); stop(); });
    if(downloadBtn) downloadBtn.addEventListener('click', (e)=>{
      e.preventDefault();
      if(!currentJob) return;
      window.location = '/api/status.php?job=' + encodeURIComponent(currentJob) + '&download=1';
    });

    // provider/auth listeners
    sel('provider1').addEventListener('change', ()=>applyProvider(1));
    sel('provider2').addEventListener('change', ()=>applyProvider(2));
    sel('auth1').addEventListener('change', ()=>applyAuth(1));
    sel('auth2').addEventListener('change', ()=>applyAuth(2));
    applyProvider(1); applyProvider(2);
    applyAuth(1); applyAuth(2);
  }

  document.addEventListener('DOMContentLoaded', function(){
    initTheme();
    initPasswordToggles();
    initLogin();
    initMigration();
  });
})();