<?php
declare(strict_types=1);

require_once __DIR__ . '/lib/bootstrap.php';
require_once __DIR__ . '/lib/i18n.php';

if (($_GET['a'] ?? '') === 'logout') { session_destroy(); header('Location: /'); exit; }

$auth = $_SESSION['auth'] ?? null;
$csrf = csrf_token();
$brand = (string)(cfg('BRAND') ?? 'BytesPulse Mailbox Migration');

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="<?=h(i18n_lang())?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title><?=h($brand)?></title>
  <link rel="stylesheet" href="/assets/app.css?v=1" />
</head>
<body>
<div class="min-h-screen flex flex-col">
  <header class="header">
    <div class="container header-inner">
      <div class="brand">
        <div class="logo">M</div>
        <div>
          <div class="brand-title"><?=h($brand)?></div>
          <div class="brand-sub"><?=h(t('header_sub'))?></div>
        </div>
      </div>

      <div class="toolbar">
        <button id="themeBtn" class="pill" type="button" title="Theme">🌙</button>
        <a class="pill" href="/?lang=<?=h(other_lang())?>"><?=h(strtoupper(other_lang()))?></a>
        <div>
          <?php if (!empty($auth['user'])): ?>
            <?=h(t('logged_in_as'))?> <span class="font-mono"><?=h($auth['user'])?></span>
            <?php if (!empty($auth['login_mode'])): ?><span class="ml-2">(<?=h($auth['login_mode'])?>)</span><?php endif; ?>
            <a class="ml-3 underline" href="/?a=logout"><?=h(t('logout'))?></a>
          <?php else: ?>
            <?=h(t('hestia_login'))?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </header>

  <?php if (empty($auth['user'])): ?>
    <main class="container" style="padding: 32px 16px; width:100%; flex:1;">
      <div class="card" style="max-width:560px; margin:0 auto;">
        <h1 style="font-size:18px; font-weight:700;"><?=h(t('login_title'))?></h1>
        <p><?=h(t('login_desc'))?></p>

        <form id="loginForm" class="row" style="margin-top:18px;">
          <input type="hidden" name="csrf" value="<?=h($csrf)?>" />

          <div>
            <label class="label"><?=h(t('username'))?></label>
            <input name="username" class="input" placeholder="hestia username" autocomplete="username" />
          </div>

          <div>
            <label class="label"><?=h(t('password_or_access'))?></label>
            <div class="input-wrap">
            <input name="credential" type="password" class="input has-eye" placeholder="password / access key" autocomplete="current-password" />
            <button type="button" class="toggle-eye" data-toggle="credential" aria-label="Show/Hide">👁</button>
          </div>
          </div>

          <div>
            <label class="label"><?=h(t('secret_optional'))?></label>
            <div class="input-wrap">
            <input name="secret" type="password" class="input has-eye" placeholder="secret key (optional)" />
            <button type="button" class="toggle-eye" data-toggle="secret" aria-label="Show/Hide">👁</button>
          </div>
          </div>

          <button class="btn btn-primary" type="submit"><?=h(t('login_btn'))?></button>
          <div id="loginMsg" class="msg hidden"></div>
        </form>

        <div class="help"><?=h(t('note_api_password'))?></div>

        <div class="card" style="margin-top:14px;">
          <div class="section-title">
            <div style="font-size:14px; font-weight:700;"><?=h(t('need_access_key'))?></div>
            <a class="underline" href="https://hestiacp.com/docs/server-administration/rest-api" target="_blank" rel="noreferrer">Hestia API docs</a>
          </div>
          <div class="help" style="font-weight:700; margin-top:0;"><?=h(t('steps_title'))?></div>
          <ol class="help" style="margin:10px 0 0 16px; padding:0; list-style:decimal;">
            <li><?=h(t('steps_1'))?></li>
            <li><?=h(t('steps_2'))?></li>
            <li><?=h(t('steps_3'))?></li>
            <li><?=h(t('steps_4'))?></li>
            <li><?=h(t('steps_5'))?></li>
          </ol>
        </div>
      </div>
    </main>
  <?php else: ?>
    <main class="container" style="padding: 24px 16px; width:100%; flex:1;">
      <input type="hidden" id="csrf" value="<?=h($csrf)?>" />

      <div class="layout">
        <section class="row" style="gap:14px;">
          <div class="card">
            <h2><?=h(t('migration_title'))?></h2>
            <p><?=h(t('migration_desc'))?></p>
          </div>

          <div class="card">
            <div class="section-title">
              <h3 style="font-size:14px; font-weight:700;"><?=h(t('sender'))?></h3>
              <span class="badge">IMAP</span>
            </div>

            <div class="row row-2">
              <div>
                <label class="label"><?=h(t('provider'))?></label>
                <select id="provider1" class="select">
                  <option value="custom"><?=h(t('custom'))?></option>
                  <option value="gmail"><?=h(t('gmail'))?></option>
                  <option value="office365"><?=h(t('office365'))?></option>
                </select>
              </div>
              <div>
                <label class="label"><?=h(t('auth_method'))?></label>
                <select id="auth1" class="select">
                  <option value="password"><?=h(t('auth_password'))?></option>
                  <option value="oauth2"><?=h(t('auth_oauth2'))?></option>
                </select>
              </div>
            </div>

            <div class="row" style="margin-top:12px;">
              <div>
                <label class="label">Host</label>
                <input id="host1" class="input" placeholder="<?=h(t('host_or_ip'))?>" />
              </div>

              <div class="row row-2">
                <div>
                  <label class="label"><?=h(t('port'))?></label>
                  <input id="port1" class="input" value="993" />
                </div>
                <label class="check" style="margin-top:24px;">
                  <input id="ssl1" type="checkbox" checked />
                  <?=h(t('ssl'))?>
                </label>
              </div>

              <div>
                <label class="label"><?=h(t('user_email'))?></label>
                <input id="user1" class="input" placeholder="user@example.com" />
              </div>

              <div id="senderPassBlock">
                <label class="label"><?=h(t('password'))?></label>
                <div class="input-wrap">
            <input id="pass1" type="password" class="input has-eye" placeholder="••••••••" />
            <button type="button" class="toggle-eye" data-toggle="pass1" aria-label="Show/Hide">👁</button>
          </div>
              </div>

              <div id="senderTokenBlock" class="hidden">
                <label class="label"><?=h(t('access_token'))?></label>
                <textarea id="token1" rows="3" class="textarea" placeholder="ya29...."></textarea>
                <div class="help">
                  Gmail XOAUTH2:
                  <a class="underline" href="https://developers.google.com/workspace/gmail/imap/xoauth2-protocol" target="_blank" rel="noreferrer">docs</a>
                  • Microsoft IMAP OAuth:
                  <a class="underline" href="https://learn.microsoft.com/en-us/exchange/client-developer/legacy-protocols/how-to-authenticate-an-imap-pop-smtp-application-by-using-oauth" target="_blank" rel="noreferrer">docs</a>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <div class="section-title">
              <h3 style="font-size:14px; font-weight:700;"><?=h(t('receiver'))?></h3>
              <span class="badge">IMAP</span>
            </div>

            <div class="row row-2">
              <div>
                <label class="label"><?=h(t('provider'))?></label>
                <select id="provider2" class="select">
                  <option value="custom"><?=h(t('custom'))?></option>
                  <option value="gmail"><?=h(t('gmail'))?></option>
                  <option value="office365"><?=h(t('office365'))?></option>
                </select>
              </div>
              <div>
                <label class="label"><?=h(t('auth_method'))?></label>
                <select id="auth2" class="select">
                  <option value="password"><?=h(t('auth_password'))?></option>
                  <option value="oauth2"><?=h(t('auth_oauth2'))?></option>
                </select>
              </div>
            </div>

            <div class="row" style="margin-top:12px;">
              <div>
                <label class="label">Host</label>
                <input id="host2" class="input" placeholder="<?=h(t('host_or_ip'))?>" />
              </div>

              <div class="row row-2">
                <div>
                  <label class="label"><?=h(t('port'))?></label>
                  <input id="port2" class="input" value="993" />
                </div>
                <label class="check" style="margin-top:24px;">
                  <input id="ssl2" type="checkbox" checked />
                  <?=h(t('ssl'))?>
                </label>
              </div>

              <div>
                <label class="label"><?=h(t('user_email'))?></label>
                <input id="user2" class="input" placeholder="user@example.com" />
              </div>

              <div id="receiverPassBlock">
                <label class="label"><?=h(t('password'))?></label>
                <div class="input-wrap">
            <input id="pass2" type="password" class="input has-eye" placeholder="••••••••" />
            <button type="button" class="toggle-eye" data-toggle="pass2" aria-label="Show/Hide">👁</button>
          </div>
              </div>

              <div id="receiverTokenBlock" class="hidden">
                <label class="label"><?=h(t('access_token'))?></label>
                <textarea id="token2" rows="3" class="textarea" placeholder="ya29...."></textarea>
                <div class="help">
                  Gmail XOAUTH2:
                  <a class="underline" href="https://developers.google.com/workspace/gmail/imap/xoauth2-protocol" target="_blank" rel="noreferrer">docs</a>
                  • Microsoft IMAP OAuth:
                  <a class="underline" href="https://learn.microsoft.com/en-us/exchange/client-developer/legacy-protocols/how-to-authenticate-an-imap-pop-smtp-application-by-using-oauth" target="_blank" rel="noreferrer">docs</a>
                </div>
              </div>
            </div>
          </div>

          <div class="card">
            <h3 style="font-size:14px; font-weight:700;"><?=h(t('options'))?></h3>

            <div class="row" style="margin-top:12px;">
              <label class="check"><input id="dryrun" type="checkbox" /> <?=h(t('test_only'))?></label>
              <label class="check"><input id="justfoldersizes" type="checkbox" /> <?=h(t('foldersizes'))?></label>
              <label class="check"><input id="automap" type="checkbox" checked /> <?=h(t('stability'))?></label>

              <div class="actions">
                <button id="startBtn" class="btn btn-primary"><?=h(t('start'))?></button>
                <button id="stopBtn" class="btn btn-outline" disabled><?=h(t('stop'))?></button>
              </div>

              <div id="msg" class="msg hidden"></div>
            </div>

            <div class="help" style="margin-top:12px;"><?=h(t('tip'))?></div>
          </div>
        </section>

        <section class="card">
          <div class="section-title">
            <h2><?=h(t('logs'))?></h2>
            <div class="badge"><?=h(t('job'))?>: <span id="jobId" class="font-mono">—</span></div>
          </div>

          <div class="progress-wrap">
            <div class="progress-top">
              <span><?=h(t('progress'))?></span>
              <span id="progressPct">—</span>
            </div>
            <div class="progress-bar">
              <div id="progressFill" class="progress-fill"></div>
              <div id="progressPulse" class="pulse hidden"></div>
            </div>
          </div>

          <div class="log-wrap">
            <pre id="log"></pre>
          </div>

          <div class="progress-top" style="margin-top:12px;">
            <span id="state"><?=h(t('idle'))?></span>
            <button id="downloadBtn" class="pill" disabled><?=h(t('download_log'))?></button>
          </div>
        </section>
      </div>
    </main>
  <?php endif; ?>

  <footer class="footer">
    Copyright © 2026 | Made by <a class="underline" href="https://bytespulse.com" target="_blank" rel="noreferrer">BytesPulse</a>
    Using <a class="underline" href="https://imapsync.lamiral.info/" target="_blank" rel="noreferrer">Lamiral&apos;s script</a>.
  </footer>
</div>

<script>
window.__APP_CONFIG = {
  missingField: <?=json_encode(t('missing_field'), JSON_UNESCAPED_UNICODE)?>,
  portNumeric: <?=json_encode(t('port_numeric'), JSON_UNESCAPED_UNICODE)?>,
  startFailed: <?=json_encode(t('start_failed'), JSON_UNESCAPED_UNICODE)?>,
  running: <?=json_encode(t('running'), JSON_UNESCAPED_UNICODE)?>,
};
</script>
<script src="/assets/app.js?v=1"></script>
</body>
</html>
